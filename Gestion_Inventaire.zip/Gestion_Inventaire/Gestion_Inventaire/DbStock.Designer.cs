﻿// La génération de code T4 est activée pour le modèle 'C:\Users\Loic Mignot\Desktop\Gestion_Inventaire\Gestion_Inventaire\DbStock.edmx'. 
// Pour activer la génération de code héritée, définissez la valeur de la propriété
// du concepteur 'Stratégie de génération de code' sur 'ObjectContext hérité'. Cette propriété est disponible dans la fenêtre Propriétés lorsque le modèle
//  est ouvert dans le concepteur.

// Si aucun contexte et classe d'entité n'a été généré, c'est peut-être parce que vous avez créé un modèle vide, mais
// que vous n'avez pas encore choisi la version d'Entity Framework à utiliser. Pour générer une classe de contexte et des classes
// d'entité pour le modèle, ouvrez le modèle dans le concepteur, cliquez avec le bouton droit sur l'aire de conception, puis
// sélectionnez 'Mettre à jour le modèle à partir de la base de données...', 'Générer une base de données à partir du modèle...' ou 'Ajouter un élément de génération
// de code...'.