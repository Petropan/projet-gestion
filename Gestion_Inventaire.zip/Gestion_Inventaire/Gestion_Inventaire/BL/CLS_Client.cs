﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Inventaire.BL
{
    class CLS_Client
    {
        private dbStockContext db = new dbStockContext();
        private Client C;
        public bool Ajouter_Client(string Nom, string Prenom, string Adresse, string Telephone, string Email, string Pays, string Ville)
        {
            C = new Client();
            C.Nom_Client = Nom;
            C.Prenom_Client = Prenom;
            C.Adresse_Client = Adresse;
            C.Telephone_Client = Telephone;
            C.Email_Client = Email;
            C.Pays_Clients = Pays;
            C.Ville_Client = Ville;

            if(db.Clients.SingleOrDefault(s=>s.Nom_Client==Nom && C.Prenom_Client==Prenom)==null)
            {
                db.Clients.Add(C);
                db.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }
        public void Modifier_Client(int id, string Nom, string Prenom, string Adresse, string Telephone, string Email, string Pays, string Ville)
        {
            C = new Client();
            C = db.Clients.SingleOrDefault(s => s.ID_Client == id);
            if (C!=null)
            {
                C.Nom_Client = Nom;
                C.Prenom_Client = Prenom;
                C.Adresse_Client = Adresse;
                C.Telephone_Client = Telephone;
                C.Email_Client = Email;
                C.Pays_Clients = Pays;
                C.Ville_Client = Ville;
                db.SaveChanges();
            }
        }
        public void Supprimer_Client(int id)
        {
            C = new Client();
            C = db.Clients.SingleOrDefault(s => s.ID_Client == id);
            if (C != null)
            {
                db.Clients.Remove(C);
                db.SaveChanges();
            }
        }
    }
}
