﻿namespace Gestion_Inventaire.PL
{
    partial class FRM_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlBut = new System.Windows.Forms.Panel();
            this.btnutilisateur = new System.Windows.Forms.Button();
            this.btncommande = new System.Windows.Forms.Button();
            this.btncategorie = new System.Windows.Forms.Button();
            this.btnproduit = new System.Windows.Forms.Button();
            this.btnclient = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlParamettrer = new System.Windows.Forms.Panel();
            this.btndeconnecter = new System.Windows.Forms.Button();
            this.btnrestaurer = new System.Windows.Forms.Button();
            this.btncopie = new System.Windows.Forms.Button();
            this.btnconnecter = new System.Windows.Forms.Button();
            this.pnlafficher = new System.Windows.Forms.Panel();
            this.btnparamettre = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.pnlParamettrer.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Controls.Add(this.pnlBut);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.btnutilisateur);
            this.panel1.Controls.Add(this.btncommande);
            this.panel1.Controls.Add(this.btncategorie);
            this.panel1.Controls.Add(this.btnproduit);
            this.panel1.Controls.Add(this.btnclient);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(108, 486);
            this.panel1.TabIndex = 0;
            // 
            // pnlBut
            // 
            this.pnlBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.pnlBut.Location = new System.Drawing.Point(4, 36);
            this.pnlBut.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.pnlBut.Name = "pnlBut";
            this.pnlBut.Size = new System.Drawing.Size(4, 21);
            this.pnlBut.TabIndex = 4;
            this.pnlBut.Paint += new System.Windows.Forms.PaintEventHandler(this.PnlBut_Paint);
            // 
            // btnutilisateur
            // 
            this.btnutilisateur.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnutilisateur.FlatAppearance.BorderSize = 0;
            this.btnutilisateur.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btnutilisateur.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnutilisateur.ForeColor = System.Drawing.Color.Black;
            this.btnutilisateur.Location = new System.Drawing.Point(1, 224);
            this.btnutilisateur.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnutilisateur.Name = "btnutilisateur";
            this.btnutilisateur.Size = new System.Drawing.Size(73, 19);
            this.btnutilisateur.TabIndex = 8;
            this.btnutilisateur.Text = "Utilisateur";
            this.btnutilisateur.UseVisualStyleBackColor = false;
            this.btnutilisateur.Click += new System.EventHandler(this.Btnutilisateur_Click);
            // 
            // btncommande
            // 
            this.btncommande.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btncommande.FlatAppearance.BorderSize = 0;
            this.btncommande.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btncommande.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncommande.ForeColor = System.Drawing.Color.Black;
            this.btncommande.Location = new System.Drawing.Point(1, 182);
            this.btncommande.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btncommande.Name = "btncommande";
            this.btncommande.Size = new System.Drawing.Size(73, 19);
            this.btncommande.TabIndex = 7;
            this.btncommande.Text = "Commande";
            this.btncommande.UseVisualStyleBackColor = false;
            this.btncommande.Click += new System.EventHandler(this.Btncommande_Click);
            // 
            // btncategorie
            // 
            this.btncategorie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btncategorie.FlatAppearance.BorderSize = 0;
            this.btncategorie.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btncategorie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncategorie.ForeColor = System.Drawing.Color.Black;
            this.btncategorie.Location = new System.Drawing.Point(1, 135);
            this.btncategorie.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btncategorie.Name = "btncategorie";
            this.btncategorie.Size = new System.Drawing.Size(73, 19);
            this.btncategorie.TabIndex = 6;
            this.btncategorie.Text = "Categorie";
            this.btncategorie.UseVisualStyleBackColor = false;
            this.btncategorie.Click += new System.EventHandler(this.Btncategorie_Click);
            // 
            // btnproduit
            // 
            this.btnproduit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnproduit.FlatAppearance.BorderSize = 0;
            this.btnproduit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btnproduit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnproduit.ForeColor = System.Drawing.Color.Black;
            this.btnproduit.Location = new System.Drawing.Point(1, 86);
            this.btnproduit.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnproduit.Name = "btnproduit";
            this.btnproduit.Size = new System.Drawing.Size(73, 19);
            this.btnproduit.TabIndex = 5;
            this.btnproduit.Text = "Produit";
            this.btnproduit.UseVisualStyleBackColor = false;
            this.btnproduit.Click += new System.EventHandler(this.Button3_Click);
            // 
            // btnclient
            // 
            this.btnclient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnclient.FlatAppearance.BorderSize = 0;
            this.btnclient.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btnclient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclient.ForeColor = System.Drawing.Color.Black;
            this.btnclient.Location = new System.Drawing.Point(1, 37);
            this.btnclient.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnclient.Name = "btnclient";
            this.btnclient.Size = new System.Drawing.Size(73, 19);
            this.btnclient.TabIndex = 4;
            this.btnclient.Text = "Client";
            this.btnclient.UseVisualStyleBackColor = false;
            this.btnclient.Click += new System.EventHandler(this.Btnclient_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(108, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(911, 4);
            this.panel2.TabIndex = 1;
            // 
            // pnlParamettrer
            // 
            this.pnlParamettrer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.pnlParamettrer.Controls.Add(this.btndeconnecter);
            this.pnlParamettrer.Controls.Add(this.btnrestaurer);
            this.pnlParamettrer.Controls.Add(this.btncopie);
            this.pnlParamettrer.Controls.Add(this.btnconnecter);
            this.pnlParamettrer.Location = new System.Drawing.Point(138, 5);
            this.pnlParamettrer.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.pnlParamettrer.Name = "pnlParamettrer";
            this.pnlParamettrer.Size = new System.Drawing.Size(163, 104);
            this.pnlParamettrer.TabIndex = 5;
            // 
            // btndeconnecter
            // 
            this.btndeconnecter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btndeconnecter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndeconnecter.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btndeconnecter.Location = new System.Drawing.Point(1, 78);
            this.btndeconnecter.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btndeconnecter.Name = "btndeconnecter";
            this.btndeconnecter.Size = new System.Drawing.Size(160, 25);
            this.btndeconnecter.TabIndex = 3;
            this.btndeconnecter.Text = "Déconnecter";
            this.btndeconnecter.UseVisualStyleBackColor = false;
            this.btndeconnecter.Click += new System.EventHandler(this.Btndeconnecter_Click);
            // 
            // btnrestaurer
            // 
            this.btnrestaurer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnrestaurer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrestaurer.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnrestaurer.Location = new System.Drawing.Point(1, 52);
            this.btnrestaurer.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnrestaurer.Name = "btnrestaurer";
            this.btnrestaurer.Size = new System.Drawing.Size(160, 25);
            this.btnrestaurer.TabIndex = 2;
            this.btnrestaurer.Text = "Restaurer une copie enregistrée";
            this.btnrestaurer.UseVisualStyleBackColor = false;
            // 
            // btncopie
            // 
            this.btncopie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btncopie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncopie.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btncopie.Location = new System.Drawing.Point(1, 26);
            this.btncopie.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btncopie.Name = "btncopie";
            this.btncopie.Size = new System.Drawing.Size(160, 25);
            this.btncopie.TabIndex = 1;
            this.btncopie.Text = "Créer une copie de l\'application";
            this.btncopie.UseVisualStyleBackColor = false;
            // 
            // btnconnecter
            // 
            this.btnconnecter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnconnecter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnconnecter.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnconnecter.Location = new System.Drawing.Point(1, 1);
            this.btnconnecter.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnconnecter.Name = "btnconnecter";
            this.btnconnecter.Size = new System.Drawing.Size(160, 25);
            this.btnconnecter.TabIndex = 0;
            this.btnconnecter.Text = "Connecter";
            this.btnconnecter.UseVisualStyleBackColor = false;
            this.btnconnecter.Click += new System.EventHandler(this.Button4_Click);
            // 
            // pnlafficher
            // 
            this.pnlafficher.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlafficher.BackColor = System.Drawing.SystemColors.Control;
            this.pnlafficher.Location = new System.Drawing.Point(110, 111);
            this.pnlafficher.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.pnlafficher.Name = "pnlafficher";
            this.pnlafficher.Size = new System.Drawing.Size(909, 370);
            this.pnlafficher.TabIndex = 6;
            // 
            // btnparamettre
            // 
            this.btnparamettre.FlatAppearance.BorderSize = 0;
            this.btnparamettre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnparamettre.Image = global::Gestion_Inventaire.Properties.Resources.parametre;
            this.btnparamettre.Location = new System.Drawing.Point(110, 5);
            this.btnparamettre.Margin = new System.Windows.Forms.Padding(1);
            this.btnparamettre.Name = "btnparamettre";
            this.btnparamettre.Size = new System.Drawing.Size(21, 18);
            this.btnparamettre.TabIndex = 4;
            this.btnparamettre.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = global::Gestion_Inventaire.Properties.Resources.trait;
            this.button2.Location = new System.Drawing.Point(970, 5);
            this.button2.Margin = new System.Windows.Forms.Padding(1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(21, 18);
            this.button2.TabIndex = 3;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::Gestion_Inventaire.Properties.Resources.Button1;
            this.button1.Location = new System.Drawing.Point(998, 5);
            this.button1.Margin = new System.Windows.Forms.Padding(1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(21, 18);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = global::Gestion_Inventaire.Properties.Resources.Menu;
            this.button3.Location = new System.Drawing.Point(81, 9);
            this.button3.Margin = new System.Windows.Forms.Padding(1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(21, 18);
            this.button3.TabIndex = 4;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click_1);
            // 
            // FRM_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1019, 486);
            this.Controls.Add(this.pnlafficher);
            this.Controls.Add(this.pnlParamettrer);
            this.Controls.Add(this.btnparamettre);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Name = "FRM_Menu";
            this.Text = "FRM_Menu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FRM_Menu_Load);
            this.panel1.ResumeLayout(false);
            this.pnlParamettrer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnclient;
        private System.Windows.Forms.Button btnutilisateur;
        private System.Windows.Forms.Button btncommande;
        private System.Windows.Forms.Button btncategorie;
        private System.Windows.Forms.Button btnproduit;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel pnlBut;
        private System.Windows.Forms.Button btnparamettre;
        private System.Windows.Forms.Panel pnlParamettrer;
        private System.Windows.Forms.Button btndeconnecter;
        private System.Windows.Forms.Button btnrestaurer;
        private System.Windows.Forms.Button btncopie;
        private System.Windows.Forms.Button btnconnecter;
        private System.Windows.Forms.Panel pnlafficher;
    }
}