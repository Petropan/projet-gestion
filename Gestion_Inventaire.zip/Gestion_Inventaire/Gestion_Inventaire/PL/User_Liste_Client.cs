﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Inventaire.PL
{
    public partial class User_Liste_Client : UserControl
    {
        private static User_Liste_Client Userclient;
        private dbStockContext db;
        public static User_Liste_Client Instance
        {
            get
            {
                if(Userclient==null)
                {
                    Userclient = new User_Liste_Client();
                }
                return Userclient;
            }
        }
        
        

        public User_Liste_Client()
        {
            InitializeComponent();
            db = new dbStockContext();
            txtrecherche.Enabled = false;
        }

        public void Actualisedatagrid()
        {
            db = new dbStockContext();
            dvgclient.Rows.Clear();
            foreach(var S in db.Clients)
            {
                dvgclient.Rows.Add(false, S.ID_Client, S.Nom_Client, S.Prenom_Client, S.Adresse_Client, S.Telephone_Client, S.Email_Client, S.Pays_Clients, S.Ville_Client);
            }
        }

        public string SelectVerif()
        {
            int Nombreligneselect = 0;
            for (int i=0; i<dvgclient.Rows.Count;i++)
            {
                if((bool)dvgclient.Rows[i].Cells[0].Value==true)
                {
                    Nombreligneselect++;
                }
            }
            if(Nombreligneselect==0)
            {
                return "Selectionner le client que vous voulez modifier";
            }
            if (Nombreligneselect>1)
            {
                return "Selectionner seulement un seul client à modifier";
            }
            return null;

        }
        private void TextBox1_Enter(object sender, EventArgs e)
        {
            if(txtrecherche.Text=="Recherche")
            {
                txtrecherche.Text = "";
                txtrecherche.ForeColor = Color.Black;

            }
        }

        private void User_Liste_Client_Load(object sender, EventArgs e)
        {
            Actualisedatagrid();
        }

        private void Btnajouteclient_Click(object sender, EventArgs e)
        {
            PL.FRM_Ajouter_Modifier_Client frmclient = new FRM_Ajouter_Modifier_Client(this);
            frmclient.ShowDialog();
        }

        

        private void Btnmodifierclient_Click(object sender, EventArgs e)
        {
            PL.FRM_Ajouter_Modifier_Client frmclient = new PL.FRM_Ajouter_Modifier_Client(this);
            if(SelectVerif()==null)
            {
                for(int i=0; i<dvgclient.Rows.Count;i++)
                {
                    if((bool)dvgclient.Rows[i].Cells[0].Value==true)
                    {
                        frmclient.IDselect = (int)dvgclient.Rows[i].Cells[1].Value;
                        frmclient.txtNom.Text = dvgclient.Rows[i].Cells[2].Value.ToString();
                        frmclient.txtPrenom.Text = dvgclient.Rows[i].Cells[3].Value.ToString();
                        frmclient.txtadresse.Text = dvgclient.Rows[i].Cells[4].Value.ToString();
                        frmclient.txtTelephone.Text = dvgclient.Rows[i].Cells[5].Value.ToString();
                        frmclient.txtemail.Text = dvgclient.Rows[i].Cells[6].Value.ToString();
                        frmclient.txtPays.Text = dvgclient.Rows[i].Cells[7].Value.ToString();
                        frmclient.txtVille.Text = dvgclient.Rows[i].Cells[8].Value.ToString();
                    }
                }
                frmclient.lblTitre.Text = "Modifier Client";
                frmclient.btnactualiser.Visible = false;
                frmclient.ShowDialog();
            }
            else
            {
                MessageBox.Show(SelectVerif(), "Modification", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Dvgclient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Btnsupprimerclient_Click(object sender, EventArgs e)
        {
            BL.CLS_Client clclient = new BL.CLS_Client();
            int select = 0;
            for(int i=0; i<dvgclient.Rows.Count;i++)
            {
                if((bool)dvgclient.Rows[i].Cells[0].Value==true)
                {
                    select++;
                }
            }
            if(select==0)
            {
                MessageBox.Show("Aucun client sélectionné", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult R =
                MessageBox.Show("Voulez vous vraiment supprimer", "Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(R==DialogResult.Yes)
                {
                    for (int i = 0; i < dvgclient.Rows.Count; i++)
                    {
                        if ((bool)dvgclient.Rows[i].Cells[0].Value == true)
                        {
                            clclient.Supprimer_Client(int.Parse(dvgclient.Rows[i].Cells[1].Value.ToString()));
                        }
                    }
                    Actualisedatagrid();
                    MessageBox.Show("Suppression avec succès", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Suppression annulée", "Supression", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void Comborecherche_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtrecherche.Enabled = true;
            txtrecherche.Text = "";
        }

        private void Txtrecherche_TextChanged(object sender, EventArgs e)
        {
            db = new dbStockContext();
            var listrecherche = db.Clients.ToList();
            if(txtrecherche.Text!="")
            {
                switch(comborecherche.Text)
                {
                    case "Nom":
                        listrecherche = listrecherche.Where(s => s.Nom_Client.IndexOf(txtrecherche.Text, StringComparison.CurrentCultureIgnoreCase) != -1).ToList();
                        break;

                }
            }
            dvgclient.Rows.Clear();
            
            
            
        }

        private void Txtrecherche_Leave(object sender, EventArgs e)
        {

        }
    }
}
