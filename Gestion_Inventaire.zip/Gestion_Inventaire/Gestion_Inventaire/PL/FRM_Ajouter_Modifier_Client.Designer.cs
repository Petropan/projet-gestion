﻿namespace Gestion_Inventaire.PL
{
    partial class FRM_Ajouter_Modifier_Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblTitre = new System.Windows.Forms.Label();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.txtadresse = new System.Windows.Forms.TextBox();
            this.txtTelephone = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtVille = new System.Windows.Forms.TextBox();
            this.txtPays = new System.Windows.Forms.TextBox();
            this.btnactualiser = new System.Windows.Forms.Button();
            this.btnenregistrer = new System.Windows.Forms.Button();
            this.btnquitter = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(274, 5);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(4, 268);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel3.Location = new System.Drawing.Point(273, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(4, 269);
            this.panel3.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel4.Location = new System.Drawing.Point(0, 265);
            this.panel4.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(277, 4);
            this.panel4.TabIndex = 1;
            // 
            // lblTitre
            // 
            this.lblTitre.AutoSize = true;
            this.lblTitre.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTitre.Location = new System.Drawing.Point(6, 12);
            this.lblTitre.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblTitre.Name = "lblTitre";
            this.lblTitre.Size = new System.Drawing.Size(69, 13);
            this.lblTitre.TabIndex = 2;
            this.lblTitre.Text = "Ajouter Client";
            // 
            // txtNom
            // 
            this.txtNom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtNom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNom.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtNom.Location = new System.Drawing.Point(8, 38);
            this.txtNom.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.txtNom.Multiline = true;
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(99, 27);
            this.txtNom.TabIndex = 3;
            this.txtNom.Text = "Nom de client";
            this.txtNom.Enter += new System.EventHandler(this.TxtNom_Enter);
            this.txtNom.Leave += new System.EventHandler(this.TxtNom_Leave);
            // 
            // txtPrenom
            // 
            this.txtPrenom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtPrenom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPrenom.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtPrenom.Location = new System.Drawing.Point(162, 38);
            this.txtPrenom.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.txtPrenom.Multiline = true;
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(99, 27);
            this.txtPrenom.TabIndex = 4;
            this.txtPrenom.Text = "Prenom de client";
            this.txtPrenom.Enter += new System.EventHandler(this.TxtPrenom_Enter);
            this.txtPrenom.Leave += new System.EventHandler(this.TxtPrenom_Leave);
            // 
            // txtadresse
            // 
            this.txtadresse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtadresse.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtadresse.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtadresse.Location = new System.Drawing.Point(8, 83);
            this.txtadresse.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.txtadresse.Multiline = true;
            this.txtadresse.Name = "txtadresse";
            this.txtadresse.Size = new System.Drawing.Size(99, 27);
            this.txtadresse.TabIndex = 5;
            this.txtadresse.Text = "Adresse client";
            this.txtadresse.Enter += new System.EventHandler(this.Txtadresse_Enter);
            this.txtadresse.Leave += new System.EventHandler(this.Txtadresse_Leave);
            // 
            // txtTelephone
            // 
            this.txtTelephone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelephone.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtTelephone.Location = new System.Drawing.Point(162, 83);
            this.txtTelephone.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.txtTelephone.Multiline = true;
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.Size = new System.Drawing.Size(99, 27);
            this.txtTelephone.TabIndex = 6;
            this.txtTelephone.Text = "Telephone client";
            this.txtTelephone.Enter += new System.EventHandler(this.TxtTelephone_Enter);
            this.txtTelephone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTelephone_KeyPress);
            this.txtTelephone.Leave += new System.EventHandler(this.TxtTelephone_Leave);
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtemail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtemail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtemail.Location = new System.Drawing.Point(162, 132);
            this.txtemail.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(99, 27);
            this.txtemail.TabIndex = 7;
            this.txtemail.Text = "Email client";
            this.txtemail.Enter += new System.EventHandler(this.Txtemail_Enter);
            this.txtemail.Leave += new System.EventHandler(this.Txtemail_Leave);
            // 
            // txtVille
            // 
            this.txtVille.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtVille.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVille.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtVille.Location = new System.Drawing.Point(162, 182);
            this.txtVille.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.txtVille.Multiline = true;
            this.txtVille.Name = "txtVille";
            this.txtVille.Size = new System.Drawing.Size(99, 27);
            this.txtVille.TabIndex = 8;
            this.txtVille.Text = "Ville client";
            this.txtVille.Enter += new System.EventHandler(this.TxtVille_Enter);
            this.txtVille.Leave += new System.EventHandler(this.TxtVille_Leave);
            // 
            // txtPays
            // 
            this.txtPays.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtPays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPays.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtPays.Location = new System.Drawing.Point(8, 182);
            this.txtPays.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.txtPays.Multiline = true;
            this.txtPays.Name = "txtPays";
            this.txtPays.Size = new System.Drawing.Size(99, 27);
            this.txtPays.TabIndex = 9;
            this.txtPays.Text = "Pays client";
            this.txtPays.Enter += new System.EventHandler(this.TxtPays_Enter);
            this.txtPays.Leave += new System.EventHandler(this.TxtPays_Leave);
            // 
            // btnactualiser
            // 
            this.btnactualiser.BackColor = System.Drawing.Color.White;
            this.btnactualiser.Location = new System.Drawing.Point(18, 226);
            this.btnactualiser.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnactualiser.Name = "btnactualiser";
            this.btnactualiser.Size = new System.Drawing.Size(85, 26);
            this.btnactualiser.TabIndex = 10;
            this.btnactualiser.Text = "Actualiser";
            this.btnactualiser.UseVisualStyleBackColor = false;
            this.btnactualiser.Click += new System.EventHandler(this.Btnactualiser_Click);
            // 
            // btnenregistrer
            // 
            this.btnenregistrer.BackColor = System.Drawing.Color.White;
            this.btnenregistrer.Location = new System.Drawing.Point(168, 226);
            this.btnenregistrer.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnenregistrer.Name = "btnenregistrer";
            this.btnenregistrer.Size = new System.Drawing.Size(85, 26);
            this.btnenregistrer.TabIndex = 11;
            this.btnenregistrer.Text = "Enregistrer";
            this.btnenregistrer.UseVisualStyleBackColor = false;
            this.btnenregistrer.Click += new System.EventHandler(this.Btnenregistrer_Click);
            // 
            // btnquitter
            // 
            this.btnquitter.BackColor = System.Drawing.Color.White;
            this.btnquitter.Location = new System.Drawing.Point(214, 8);
            this.btnquitter.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnquitter.Name = "btnquitter";
            this.btnquitter.Size = new System.Drawing.Size(52, 28);
            this.btnquitter.TabIndex = 12;
            this.btnquitter.Text = "Quitter";
            this.btnquitter.UseVisualStyleBackColor = false;
            this.btnquitter.Click += new System.EventHandler(this.Btnquitter_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel5.Location = new System.Drawing.Point(8, 53);
            this.panel5.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(64, 4);
            this.panel5.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel6.Location = new System.Drawing.Point(162, 53);
            this.panel6.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(77, 4);
            this.panel6.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel7.Location = new System.Drawing.Point(8, 113);
            this.panel7.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(65, 4);
            this.panel7.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel8.Location = new System.Drawing.Point(162, 98);
            this.panel8.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(76, 4);
            this.panel8.TabIndex = 1;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel9.Location = new System.Drawing.Point(162, 145);
            this.panel9.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(54, 4);
            this.panel9.TabIndex = 1;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel10.Location = new System.Drawing.Point(9, 195);
            this.panel10.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(51, 4);
            this.panel10.TabIndex = 1;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel11.Location = new System.Drawing.Point(162, 195);
            this.panel11.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(47, 4);
            this.panel11.TabIndex = 1;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel12.Location = new System.Drawing.Point(3, 0);
            this.panel12.Margin = new System.Windows.Forms.Padding(1);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(277, 4);
            this.panel12.TabIndex = 13;
            // 
            // FRM_Ajouter_Modifier_Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(276, 269);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnquitter);
            this.Controls.Add(this.btnenregistrer);
            this.Controls.Add(this.btnactualiser);
            this.Controls.Add(this.txtPays);
            this.Controls.Add(this.txtVille);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtTelephone);
            this.Controls.Add(this.txtadresse);
            this.Controls.Add(this.txtPrenom);
            this.Controls.Add(this.txtNom);
            this.Controls.Add(this.lblTitre);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Name = "FRM_Ajouter_Modifier_Client";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FRM_Ajouter_Modifier_Client";
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnenregistrer;
        private System.Windows.Forms.Button btnquitter;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        public System.Windows.Forms.Label lblTitre;
        public System.Windows.Forms.Button btnactualiser;
        public System.Windows.Forms.TextBox txtNom;
        public System.Windows.Forms.TextBox txtPrenom;
        public System.Windows.Forms.TextBox txtadresse;
        public System.Windows.Forms.TextBox txtTelephone;
        public System.Windows.Forms.TextBox txtemail;
        public System.Windows.Forms.TextBox txtVille;
        public System.Windows.Forms.TextBox txtPays;
        private System.Windows.Forms.Panel panel12;
    }
}