﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;

namespace Gestion_Inventaire.PL
{
    public partial class FRM_Ajouter_Modifier_Client : Form
    {
        private UserControl usclient;
        public FRM_Ajouter_Modifier_Client(UserControl userC)
        {
            InitializeComponent();
            this.usclient = userC;
        }

        string testobligatoire()
        {
            if(txtNom.Text=="" || txtNom.Text== "Nom de client")
            {
                return "Entrer le nom de Client";
            }

            if (txtPrenom.Text == "" || txtPrenom.Text == "Prenom de client")
            {
                return "Entrer le prenom de Client";
            }

            if (txtadresse.Text == "" || txtadresse.Text == "Adresse client")
            {
                return "Entrer l'adresse de Client";
            }

            if (txtTelephone.Text == "" || txtTelephone.Text == "Telephone client")
            {
                return "Entrer le telephone de Client";
            }

            if (txtemail.Text == "" || txtemail.Text == "Email client")
            {
                return "Entrer l'email de Client";
            }
            if (txtPays.Text == "" || txtPays.Text == "Pays client")
            {
                return "Entrer Pays de Client";
            }
            if (txtVille.Text == "" || txtVille.Text == "Ville client")
            {
                return "Entrer Ville de Client";
            }

            if (txtemail.Text != "" || txtemail.Text != "Email client")
            {
                try
                {
                    new MailAddress(txtemail.Text);
                }catch(Exception e)
                {
                    return "Email invalide";
                }
            }

            return null;
        }

        private void TxtNom_Enter(object sender, EventArgs e)
        {
            if (txtNom.Text== "Nom de client")
            {
                txtNom.Text = "";
                txtNom.ForeColor = Color.Black;
            }
        }

        private void TxtNom_Leave(object sender, EventArgs e)
        {
            if (txtNom.Text == "")
            {
                txtNom.Text = "Nom de client";
                txtNom.ForeColor = Color.Silver;
            }
        }

        private void Btnquitter_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxtPrenom_Enter(object sender, EventArgs e)
        {
            if (txtPrenom.Text == "Prenom de client")
            {
                txtPrenom.Text = "";
                txtPrenom.ForeColor = Color.Black;
            }
        }

        private void TxtPrenom_Leave(object sender, EventArgs e)
        {
            if (txtPrenom.Text == "")
            {
                txtPrenom.Text = "Prenom de client";
                txtPrenom.ForeColor = Color.Silver;
            }
        }

        private void Txtadresse_Enter(object sender, EventArgs e)
        {
            if (txtadresse.Text == "Adresse client")
            {
                txtadresse.Text = "";
                txtadresse.ForeColor = Color.Black;
            }
        }

        private void Txtadresse_Leave(object sender, EventArgs e)
        {
            if (txtadresse.Text == "")
            {
                txtadresse.Text = "Adresse client";
                txtadresse.ForeColor = Color.Silver;
            }
        }

        private void TxtTelephone_Enter(object sender, EventArgs e)
        {
            if (txtTelephone.Text == "Telephone client")
            {
                txtTelephone.Text = "";
                txtTelephone.ForeColor = Color.Black;
            }
        }

        private void TxtTelephone_Leave(object sender, EventArgs e)
        {
            if (txtTelephone.Text == "")
            {
                txtTelephone.Text = "Telepone client";
                txtTelephone.ForeColor = Color.Silver;
            }
        }

        private void Txtemail_Enter(object sender, EventArgs e)
        {
            if (txtemail.Text == "Email client")
            {
                txtemail.Text = "";
                txtemail.ForeColor = Color.Black;
            }
        }

        private void Txtemail_Leave(object sender, EventArgs e)
        {
            if (txtemail.Text == "")
            {
                txtemail.Text = "Email client";
                txtemail.ForeColor = Color.Silver;
            }
        }

        private void TxtPays_Enter(object sender, EventArgs e)
        {
            if (txtPays.Text == "Pays client")
            {
                txtPays.Text = "";
                txtPays.ForeColor = Color.Black;
            }
        }

        private void TxtPays_Leave(object sender, EventArgs e)
        {
            if (txtPays.Text == "")
            {
                txtPays.Text = "Pays client";
                txtPays.ForeColor = Color.Silver;
            }
        }

        private void TxtVille_Enter(object sender, EventArgs e)
        {
            if (txtVille.Text == "Ville client")
            {
                txtVille.Text = "";
                txtVille.ForeColor = Color.Black;
            }
        }

        private void TxtVille_Leave(object sender, EventArgs e)
        {
            if (txtVille.Text == "")
            {
                txtVille.Text = "Ville client";
                txtVille.ForeColor = Color.Silver;
            }
        }

        private void TxtTelephone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar<48 || e.KeyChar>57)
            {
                e.Handled = true;
            }
            if(e.KeyChar==8)
            {
                e.Handled = false;
            }
        }
        public int IDselect;
        private void Btnenregistrer_Click(object sender, EventArgs e)
        {
            if (testobligatoire()!=null)
            {
                MessageBox.Show(testobligatoire(),"Obligatoire",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else

            if(lblTitre.Text=="Ajouter Client")
            {
                BL.CLS_Client clclient = new BL.CLS_Client();
                if (clclient.Ajouter_Client(txtNom.Text, txtPrenom.Text, txtadresse.Text, txtTelephone.Text, txtemail.Text, txtPays.Text, txtVille.Text) == true)
                {
                    MessageBox.Show("Client ajouté avec succès", "Ajouter", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    (usclient as User_Liste_Client).Actualisedatagrid();
                }
                else
                {
                    MessageBox.Show("Nom et prenom déjà existant", "Ajouter", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                BL.CLS_Client clclient = new BL.CLS_Client();
                DialogResult R = MessageBox.Show("Voulez vous vraiment modifier ce client", "Modification", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(R==DialogResult.Yes)
                {
                    clclient.Modifier_Client(IDselect, txtNom.Text, txtPrenom.Text, txtadresse.Text, txtTelephone.Text, txtemail.Text, txtPays.Text, txtVille.Text);
                    (usclient as User_Liste_Client).Actualisedatagrid();
                    MessageBox.Show("Client modifié avec succès", "Modification", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("La modification est annulée", "Modification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                
            }
        }

        private void Btnactualiser_Click(object sender, EventArgs e)
        {
            txtNom.Text = "Nom de Client"; txtNom.ForeColor = Color.Silver;
            txtPrenom.Text = "Prenom de Client"; txtPrenom.ForeColor = Color.Silver;
            txtadresse.Text = "Adresse Client"; txtadresse.ForeColor = Color.Silver;
            txtTelephone.Text = "Telephone Client"; txtTelephone.ForeColor = Color.Silver;
            txtemail.Text = "Email Client"; txtemail.ForeColor = Color.Silver;
            txtPays.Text = "Pays Client"; txtPays.ForeColor = Color.Silver;
            txtVille.Text = "Ville Client"; txtVille.ForeColor = Color.Silver;
        }
    }
}
