﻿namespace Gestion_Inventaire.PL
{
    partial class FRM_Ajouter_Modifier_Produit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitre = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnparcourir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.combocategorie = new System.Windows.Forms.ComboBox();
            this.PicProduit = new System.Windows.Forms.PictureBox();
            this.txtNomP = new System.Windows.Forms.TextBox();
            this.txtquantite = new System.Windows.Forms.TextBox();
            this.txtprix = new System.Windows.Forms.TextBox();
            this.btnenregistrer = new System.Windows.Forms.Button();
            this.btnactualiser = new System.Windows.Forms.Button();
            this.btnquitter = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.PicProduit)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitre
            // 
            this.lblTitre.AutoSize = true;
            this.lblTitre.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTitre.Location = new System.Drawing.Point(10, 26);
            this.lblTitre.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblTitre.Name = "lblTitre";
            this.lblTitre.Size = new System.Drawing.Size(76, 13);
            this.lblTitre.TabIndex = 3;
            this.lblTitre.Text = "Ajouter Produit";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(13, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Image";
            // 
            // btnparcourir
            // 
            this.btnparcourir.BackColor = System.Drawing.Color.White;
            this.btnparcourir.Location = new System.Drawing.Point(171, 191);
            this.btnparcourir.Name = "btnparcourir";
            this.btnparcourir.Size = new System.Drawing.Size(77, 23);
            this.btnparcourir.TabIndex = 6;
            this.btnparcourir.Text = "Parcourir";
            this.btnparcourir.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(295, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Catégorie";
            // 
            // combocategorie
            // 
            this.combocategorie.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.combocategorie.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combocategorie.FormattingEnabled = true;
            this.combocategorie.Items.AddRange(new object[] {
            "Nom",
            "Categorie"});
            this.combocategorie.Location = new System.Drawing.Point(353, 66);
            this.combocategorie.Margin = new System.Windows.Forms.Padding(1);
            this.combocategorie.Name = "combocategorie";
            this.combocategorie.Size = new System.Drawing.Size(140, 33);
            this.combocategorie.TabIndex = 15;
            // 
            // PicProduit
            // 
            this.PicProduit.BackColor = System.Drawing.Color.White;
            this.PicProduit.Location = new System.Drawing.Point(75, 78);
            this.PicProduit.Name = "PicProduit";
            this.PicProduit.Size = new System.Drawing.Size(173, 88);
            this.PicProduit.TabIndex = 4;
            this.PicProduit.TabStop = false;
            // 
            // txtNomP
            // 
            this.txtNomP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtNomP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNomP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtNomP.Location = new System.Drawing.Point(298, 125);
            this.txtNomP.Margin = new System.Windows.Forms.Padding(1);
            this.txtNomP.Multiline = true;
            this.txtNomP.Name = "txtNomP";
            this.txtNomP.Size = new System.Drawing.Size(99, 27);
            this.txtNomP.TabIndex = 16;
            this.txtNomP.Text = "Nom Produit";
            this.txtNomP.Enter += new System.EventHandler(this.TxtNomP_Enter);
            this.txtNomP.Leave += new System.EventHandler(this.TxtNomP_Leave);
            // 
            // txtquantite
            // 
            this.txtquantite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtquantite.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtquantite.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtquantite.Location = new System.Drawing.Point(298, 154);
            this.txtquantite.Margin = new System.Windows.Forms.Padding(1);
            this.txtquantite.Multiline = true;
            this.txtquantite.Name = "txtquantite";
            this.txtquantite.Size = new System.Drawing.Size(99, 27);
            this.txtquantite.TabIndex = 17;
            this.txtquantite.Text = "Quantité";
            this.txtquantite.Enter += new System.EventHandler(this.Txtquantite_Enter);
            this.txtquantite.Leave += new System.EventHandler(this.Txtquantite_Leave);
            // 
            // txtprix
            // 
            this.txtprix.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtprix.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtprix.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtprix.Location = new System.Drawing.Point(298, 183);
            this.txtprix.Margin = new System.Windows.Forms.Padding(1);
            this.txtprix.Multiline = true;
            this.txtprix.Name = "txtprix";
            this.txtprix.Size = new System.Drawing.Size(99, 27);
            this.txtprix.TabIndex = 18;
            this.txtprix.Text = "Prix";
            this.txtprix.Enter += new System.EventHandler(this.Txtprix_Enter);
            this.txtprix.Leave += new System.EventHandler(this.Txtprix_Leave);
            // 
            // btnenregistrer
            // 
            this.btnenregistrer.BackColor = System.Drawing.Color.White;
            this.btnenregistrer.Location = new System.Drawing.Point(371, 246);
            this.btnenregistrer.Margin = new System.Windows.Forms.Padding(1);
            this.btnenregistrer.Name = "btnenregistrer";
            this.btnenregistrer.Size = new System.Drawing.Size(85, 26);
            this.btnenregistrer.TabIndex = 20;
            this.btnenregistrer.Text = "Enregistrer";
            this.btnenregistrer.UseVisualStyleBackColor = false;
            // 
            // btnactualiser
            // 
            this.btnactualiser.BackColor = System.Drawing.Color.White;
            this.btnactualiser.Location = new System.Drawing.Point(75, 246);
            this.btnactualiser.Margin = new System.Windows.Forms.Padding(1);
            this.btnactualiser.Name = "btnactualiser";
            this.btnactualiser.Size = new System.Drawing.Size(85, 26);
            this.btnactualiser.TabIndex = 19;
            this.btnactualiser.Text = "Actualiser";
            this.btnactualiser.UseVisualStyleBackColor = false;
            // 
            // btnquitter
            // 
            this.btnquitter.BackColor = System.Drawing.Color.White;
            this.btnquitter.Location = new System.Drawing.Point(446, 10);
            this.btnquitter.Margin = new System.Windows.Forms.Padding(1);
            this.btnquitter.Name = "btnquitter";
            this.btnquitter.Size = new System.Drawing.Size(47, 29);
            this.btnquitter.TabIndex = 21;
            this.btnquitter.Text = "Quitter";
            this.btnquitter.UseVisualStyleBackColor = false;
            this.btnquitter.Click += new System.EventHandler(this.Btnquitter_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel1.Location = new System.Drawing.Point(511, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(4, 288);
            this.panel1.TabIndex = 22;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel2.Location = new System.Drawing.Point(6, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(515, 4);
            this.panel2.TabIndex = 23;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel3.Location = new System.Drawing.Point(0, 2);
            this.panel3.Margin = new System.Windows.Forms.Padding(1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(4, 295);
            this.panel3.TabIndex = 24;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.panel4.Location = new System.Drawing.Point(3, 284);
            this.panel4.Margin = new System.Windows.Forms.Padding(1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(515, 4);
            this.panel4.TabIndex = 25;
            // 
            // FRM_Ajouter_Modifier_Produit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(515, 288);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnquitter);
            this.Controls.Add(this.btnenregistrer);
            this.Controls.Add(this.btnactualiser);
            this.Controls.Add(this.txtprix);
            this.Controls.Add(this.txtquantite);
            this.Controls.Add(this.txtNomP);
            this.Controls.Add(this.combocategorie);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnparcourir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PicProduit);
            this.Controls.Add(this.lblTitre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FRM_Ajouter_Modifier_Produit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FRM_Ajouter_Modifier_Produit";
            ((System.ComponentModel.ISupportInitialize)(this.PicProduit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblTitre;
        private System.Windows.Forms.PictureBox PicProduit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnparcourir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox combocategorie;
        public System.Windows.Forms.TextBox txtNomP;
        public System.Windows.Forms.TextBox txtquantite;
        public System.Windows.Forms.TextBox txtprix;
        private System.Windows.Forms.Button btnenregistrer;
        public System.Windows.Forms.Button btnactualiser;
        private System.Windows.Forms.Button btnquitter;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
    }
}