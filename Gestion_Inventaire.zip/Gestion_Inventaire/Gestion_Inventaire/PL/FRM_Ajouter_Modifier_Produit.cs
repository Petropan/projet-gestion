﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Inventaire.PL
{
    public partial class FRM_Ajouter_Modifier_Produit : Form
    {
        public FRM_Ajouter_Modifier_Produit()
        {
            InitializeComponent();
        }

        private void TxtNomP_Enter(object sender, EventArgs e)
        {
            if(txtNomP.Text == "Nom Produit")
            {
                txtNomP.Text = "";
                txtNomP.ForeColor = Color.White;
            }
        }

        private void TxtNomP_Leave(object sender, EventArgs e)
        {
            if (txtNomP.Text == "")
            {
                txtNomP.Text = "Nom Produit";
                txtNomP.ForeColor = Color.Silver;
            }
        }

        private void Txtquantite_Enter(object sender, EventArgs e)
        {
            if (txtNomP.Text == "Quantité")
            {
                txtNomP.Text = "";
                txtNomP.ForeColor = Color.White;
            }
        }

        private void Txtquantite_Leave(object sender, EventArgs e)
        {
            if (txtNomP.Text == "")
            {
                txtNomP.Text = "Quantité";
                txtNomP.ForeColor = Color.Silver;
            }
        }

        private void Txtprix_Enter(object sender, EventArgs e)
        {
            if (txtNomP.Text == "Prix")
            {
                txtNomP.Text = "";
                txtNomP.ForeColor = Color.White;
            }
        }

        private void Txtprix_Leave(object sender, EventArgs e)
        {
            if (txtNomP.Text == "")
            {
                txtNomP.Text = "Prix";
                txtNomP.ForeColor = Color.Silver;
            }
        }

        private void Btnquitter_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
