﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Inventaire.PL
{
    public partial class FRM_Menu : Form
    {
        public FRM_Menu()
        {
            InitializeComponent();
            panel1.Size = new Size(200, 652);
        }

        void desactiverForm()
        {
            btnclient.Enabled = false;
            btnproduit.Enabled = false;
            btncategorie.Enabled = false;
            btncommande.Enabled = false;
            btnutilisateur.Enabled = false;
            btncopie.Enabled = false;
            btnrestaurer.Enabled = false;
            btndeconnecter.Enabled = false;
            pnlBut.Enabled = false;
            btnconnecter.Enabled = true;
        }

        public void activerForm()
        {
            btnclient.Enabled = true;
            btnproduit.Enabled = true;
            btncategorie.Enabled = true;
            btncommande.Enabled = true;
            btnutilisateur.Enabled = true;
            btncopie.Enabled = true;
            btnrestaurer.Enabled = true;
            btndeconnecter.Enabled = true;
            pnlBut.Enabled = true;
            btnconnecter.Enabled = false;
            pnlParamettrer.Visible = false;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            pnlBut.Top = btnproduit.Top;
            if (!pnlafficher.Controls.Contains(User_Liste_Client.Instance))
            {
                pnlafficher.Controls.Add(USER_Liste_Produit.Instance);
                USER_Liste_Produit.Instance.Dock = DockStyle.Fill;
                USER_Liste_Produit.Instance.BringToFront();
            }
            else
            {
                USER_Liste_Produit.Instance.BringToFront();
            }
        }

        private void Btnclient_Click(object sender, EventArgs e)
        {
            pnlBut.Top = btnclient.Top;
            if(!pnlafficher.Controls.Contains(User_Liste_Client.Instance))
            {
                pnlafficher.Controls.Add(User_Liste_Client.Instance);
                User_Liste_Client.Instance.Dock = DockStyle.Fill;
                User_Liste_Client.Instance.BringToFront();
            }
            else
            {
                User_Liste_Client.Instance.BringToFront();
            }
        }

        private void Btncommande_Click(object sender, EventArgs e)
        {
            pnlBut.Top = btncommande.Top;
        }

        private void Button3_Click_1(object sender, EventArgs e)
        {
            if (panel1.Width == 200)
            {
                panel1.Size = new Size(194, 652);
            }
            else
            {
                panel1.Size = new Size(288, 652);
            }
        }

        private void PnlBut_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Btncategorie_Click(object sender, EventArgs e)
        {
            pnlBut.Top = btncategorie.Top;
        }

        private void Btnutilisateur_Click(object sender, EventArgs e)
        {
            pnlBut.Top = btnutilisateur.Top;
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            FRM_Connexion frmC = new FRM_Connexion(this);
            frmC.ShowDialog();
        }

        private void FRM_Menu_Load(object sender, EventArgs e)
        {
            desactiverForm();
        }

        private void Btndeconnecter_Click(object sender, EventArgs e)
        {
            desactiverForm();
        }
    }
}
