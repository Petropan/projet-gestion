﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Inventaire.PL
{
    public partial class FRM_Connexion : Form
    {
        private dbStockContext db;
        private Form frmmenu;
        BL.CLS_Connexion C = new BL.CLS_Connexion();
        public FRM_Connexion(Form Menu)
        {
            InitializeComponent();
            this.frmmenu = Menu;

            db = new dbStockContext();
        }

        string testobligatoire()
        {
            if(txtNom.Text=="" || txtNom.Text== "Nom d'utilisateur")
            {
                return "Entrer votre nom";
            }
            if (txtmotdepasse.Text == "" || txtmotdepasse.Text == "Mot de Passe")
            {
                return "Entrer votre mot de passe";
            }
            return null;
        }

        private void Btnquitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtNom_Enter(object sender, EventArgs e)
        {
            if (txtNom.Text == "Nom d'utilisateur")
            {
                txtNom.Text = "";
                txtNom.ForeColor = Color.Black;

            }
        }

        private void txtmotdepasse_Enter(object sender, EventArgs e)
        {
            if (txtmotdepasse.Text == "Mot de Passe")
            {
                txtmotdepasse.Text = "";
                txtmotdepasse.UseSystemPasswordChar = false;
                txtmotdepasse.PasswordChar = '*';
                txtmotdepasse.ForeColor = Color.Black;
            }
        }

        private void txtNom_Leave(object sender, EventArgs e)
        {
            if (txtNom.Text=="")
            {
                txtNom.Text = "Nom d'utilisateur";
                txtNom.ForeColor = Color.Black;
            }
        }

        private void txtmotdepasse_Leave(object sender, EventArgs e)
        {
            if (txtmotdepasse.Text == "")
            {
                txtmotdepasse.Text = "Mot de passe";
                txtmotdepasse.UseSystemPasswordChar = true;
                txtmotdepasse.ForeColor = Color.Black;
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if(testobligatoire()==null)
            {
                if(C.ConnexionValide(db,txtNom.Text,txtmotdepasse.Text)==true)
                {
                    MessageBox.Show("Connexion a réussi", "Connexion", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    (frmmenu as FRM_Menu).activerForm();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Connexion a échoué", "Connexion", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else
            {
                MessageBox.Show(testobligatoire(), "obligatoire", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtNom_TextChanged(object sender, EventArgs e)
        {

        }
    }
 }